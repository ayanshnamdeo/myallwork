package com.nagarro.anno.dao;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.nagarro.anno.entity.User;

/**
 * @author ayanshnamdeo
 *
 */
@SpringBootTest
public class UserDaoTest {
	
	@Autowired
	private UserDao dao;
	
	@Test
	void contextLoads() {
		
	}
	
	
	@Test
	void isUserExistsById() {
		User user=new User(4,"ashi@gmail.com","ashi");
		
		dao.save(user);
		
		Boolean actualRes=dao.isUserExistsById(3);
		assertThat(actualRes).isTrue();
	}
	
	//har ek test function k baad automatic chalega
	@AfterEach
	void tearDown() {
		System.out.println("After tear down ");
		//delete all those created on test cases
		dao.deleteAll();
	}
	//har ek test k phle chalega
	@BeforeEach
	void setUp() {
		System.out.println("before setup ");
		
	}
}
