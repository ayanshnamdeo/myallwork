package com.nagarro.anno;

import org.springframework.boot.test.context.SpringBootTest;


import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Unit test for simple App.
 */
@SpringBootTest
public class AppTest {
	private Calculator c=new Calculator();
	
	
	@Test
	void contextLoads() {
		
	}
	


	
	@Test
	void testSum() {
		//expected
		int expectedRes=22;
		//actual
		int actualRes=c.doSum(12,3,7);
		//check
		assertThat(actualRes).isEqualTo(expectedRes);
		
	}
	
	@Test
	void testProduct() {
		//expected
				int expectedRes=36;
				//actual
				int actualRes=c.doProduct(12,3);
				//check
				assertThat(actualRes).isEqualTo(expectedRes);
		
	}
	
	//compare
	@Test
	void testCompareTwoNums() {
		//expected
//		boolean expectedRes=false;
		//actual
		boolean actualRes=c.compareTwoNums(12,3);
		//check
//		assertThat(actualRes).isEqualTo(expectedRes);
		assertThat(actualRes).isFalse();

		
	}

   
}
