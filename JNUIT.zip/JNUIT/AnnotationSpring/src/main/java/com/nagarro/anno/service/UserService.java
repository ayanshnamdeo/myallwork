package com.nagarro.anno.service;

import java.util.List;


import org.springframework.stereotype.Service;

import com.nagarro.anno.entity.User;


@Service
public interface UserService {
	public List<User> users();

}
