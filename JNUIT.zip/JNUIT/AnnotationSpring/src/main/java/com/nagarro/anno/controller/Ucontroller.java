package com.nagarro.anno.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nagarro.anno.entity.User;
import com.nagarro.anno.service.UserService;


@RestController
public class Ucontroller{
	@Autowired
	private UserService userService;
	
	@GetMapping("/user")
	public List<User> getUser() {
		return this.userService.users();
	}
	
}
