package com.nagarro.anno.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nagarro.anno.entity.User;

public interface UserDao extends JpaRepository<User, Integer>{

	@Query("SELECT CASE WHEN COUNT(s) >0  THEN TRUE ELSE FALSE END FROM User s where s.id =:uid")
	Boolean isUserExistsById(Integer  uid);

}
