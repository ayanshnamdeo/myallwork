package com.nagarro.anno.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nagarro.anno.dao.UserDao;
import com.nagarro.anno.entity.User;
import com.nagarro.anno.service.UserService;


@Component
public class UserServiceImp implements UserService {
	
	@Autowired
	private UserDao userDao;

	@Override
	public List<User> users() {
		// TODO Auto-generated method stub
		return (List<User>) userDao.findAll();
	}

}
