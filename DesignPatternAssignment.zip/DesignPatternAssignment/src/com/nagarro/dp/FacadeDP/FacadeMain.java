package com.nagarro.dp.FacadeDP;

import com.nagarro.dp.Email;
import com.nagarro.dp.Notification;
import com.nagarro.dp.SMS;

public class FacadeMain {
	public static void main(String[] args) {
        String channel = args[0]; // Email or SMS
        String subject = args[1];
        String message = args[2];

        NotificationFacade facade = new NotificationFacade();

        // Subscribe users (mocked)
        facade.subscribe("FacadeA");
        facade.subscribe("FacadeB");
        // Add more subscribers as needed

        // Create the appropriate notification
        Notification notification;
        if (channel.equalsIgnoreCase("Email")) {
            notification = new Email();
        } else if (channel.equalsIgnoreCase("SMS")) {
            notification = new SMS();
        } else {
            throw new IllegalArgumentException("Invalid channel");
        }

        // Send notification to subscribers
        facade.sendNotification(notification, subject, message);
    }

}
