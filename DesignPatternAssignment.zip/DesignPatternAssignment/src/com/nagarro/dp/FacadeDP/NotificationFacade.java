package com.nagarro.dp.FacadeDP;

import com.nagarro.dp.Notification;

public class NotificationFacade {
	private NotificationService notificationService;

    public NotificationFacade() {
        notificationService = NotificationService.getInstance();
    }

    public void subscribe(String subscriber) {
        notificationService.subscribe(subscriber);
    }

    public void sendNotification(Notification notification, String subject, String message) {
        notificationService.notifySubscribers(notification, subject, message);
    }

}
