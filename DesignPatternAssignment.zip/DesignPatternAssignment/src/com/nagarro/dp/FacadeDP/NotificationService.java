package com.nagarro.dp.FacadeDP;

import java.util.ArrayList;
import java.util.List;

import com.nagarro.dp.Notification;

public class NotificationService {
	private static NotificationService instance;
    private List<String> subscribers;

    private NotificationService() {
        subscribers = new ArrayList<>();
    }

    public static synchronized NotificationService getInstance() {
        if (instance == null) {
            instance = new NotificationService();
        }
        return instance;
    }

    public void subscribe(String subscriber) {
        subscribers.add(subscriber);
    }

    public void notifySubscribers(Notification notification, String subject, String message) {
        for (String subscriber : subscribers) {
            notification.send(subject, message + " for " + subscriber);
        }
    }

}
