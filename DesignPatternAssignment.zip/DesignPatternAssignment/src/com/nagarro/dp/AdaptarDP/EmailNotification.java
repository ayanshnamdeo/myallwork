package com.nagarro.dp.AdaptarDP;

public class EmailNotification {
	 public void sendEmail(String emailAddress, String subject, String message) {
	        System.out.println("Sending Email Notification to " + emailAddress);
	        System.out.println("Subject: " + subject);
	        System.out.println("Message: " + message);
	    }

}
