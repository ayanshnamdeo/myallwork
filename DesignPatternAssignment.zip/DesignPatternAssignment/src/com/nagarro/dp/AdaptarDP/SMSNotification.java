package com.nagarro.dp.AdaptarDP;

public class SMSNotification {
	
	public void sendSMS(String phoneNumber, String message) {
        System.out.println("Sending SMS Notification to " + phoneNumber);
        System.out.println("Message: " + message);
    }

}
