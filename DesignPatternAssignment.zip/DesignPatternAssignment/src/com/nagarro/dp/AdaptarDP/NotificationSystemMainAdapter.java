package com.nagarro.dp.AdaptarDP;

import com.nagarro.dp.Notification;

public class NotificationSystemMainAdapter {
	public static void main(String[] args) {
        if (args.length < 3) {
            System.out.println("Usage: java NotificationSystem <channel> <subject> <message>");
            return;
        }

        String channel = args[0].toLowerCase();
        String subject = args[1];
        String message = args[2];

        Notification notification = createNotification(channel);
        notification.send(subject, message);
    }
	private static Notification createNotification(String channel) {
        if (channel.equals("email")) {
            EmailNotification emailNotification = new EmailNotification();
            return new EmailNotificationAdapter(emailNotification);
        } else if (channel.equals("sms")) {
            SMSNotification smsNotification = new SMSNotification();
            return new SMSNotificationAdapter(smsNotification);
        } else {
            throw new IllegalArgumentException("Unsupported channel: " + channel);
        }
    }

}
