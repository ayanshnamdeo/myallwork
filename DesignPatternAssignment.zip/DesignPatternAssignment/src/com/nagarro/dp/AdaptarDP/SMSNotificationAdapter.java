package com.nagarro.dp.AdaptarDP;

import java.util.ArrayList;
import java.util.List;

import com.nagarro.dp.Notification;

public class SMSNotificationAdapter implements Notification{
	 private SMSNotification smsNotification;

	    public SMSNotificationAdapter(SMSNotification smsNotification) {
	        this.smsNotification = smsNotification;
	    }

	    @Override
	    public void send(String subject, String message) {
	        // Assuming all subscribed phone numbers receive the notification
	        List<String> subscribedPhoneNumbers = getSubscribedPhoneNumbers();
	        for (String phoneNumber : subscribedPhoneNumbers) {
	            smsNotification.sendSMS(phoneNumber, message);
	        }
	    }

	    private List<String> getSubscribedPhoneNumbers() {
	        List<String> subscribedPhoneNumbers = new ArrayList<>();
	        // Mocked phone numbers
	        subscribedPhoneNumbers.add("1234567890");
	        subscribedPhoneNumbers.add("9876543210");
	        return subscribedPhoneNumbers;
	    }

}
