package com.nagarro.dp.AdaptarDP;

import java.util.ArrayList;
import java.util.List;

import com.nagarro.dp.Notification;

public class EmailNotificationAdapter implements Notification{

	private EmailNotification emailNotification;

    public EmailNotificationAdapter(EmailNotification emailNotification) {
        this.emailNotification = emailNotification;
    }

    @Override
    public void send(String subject, String message) {
        // Assuming all subscribed email addresses receive the notification
        List<String> subscribedEmails = getSubscribedEmails();
        for (String emailAddress : subscribedEmails) {
            emailNotification.sendEmail(emailAddress, subject, message);
        }
    }

    private List<String> getSubscribedEmails() {
        List<String> subscribedEmails = new ArrayList<>();
        // Mocked email addresses
        subscribedEmails.add("Adapter1@example.com");
        subscribedEmails.add("adapter2@example.com");
        return subscribedEmails;
    }

}
