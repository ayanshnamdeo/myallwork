package com.nagarro.dp;

public class SMS implements Notification {

	@Override
	public void send(String subject, String message) {
		
		System.out.println("Sending SMS Notification:");
        System.out.println("Subject: " + subject);
        System.out.println("Message: " + message);
		
	}
	

}
