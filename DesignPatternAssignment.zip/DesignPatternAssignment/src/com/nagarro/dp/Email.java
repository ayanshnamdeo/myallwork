package com.nagarro.dp;

public class Email implements Notification {

	@Override
	public void send(String subject, String message) {
		
		System.out.println("Sending Email Notification:");
        System.out.println("Subject: " + subject);
        System.out.println("Message: " + message);
		
	}
	

}
