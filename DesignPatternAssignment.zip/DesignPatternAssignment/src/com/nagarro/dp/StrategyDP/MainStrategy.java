package com.nagarro.dp.StrategyDP;

import com.nagarro.dp.Email;
import com.nagarro.dp.Notification;
import com.nagarro.dp.SMS;

public class MainStrategy {
	 public static void main(String[] args) {
	 Notification emailStrategy = new Email();
     Notification smsStrategy = new SMS();

     // Create notification senders
     NotificationSender emailSender = new NotificationSender(emailStrategy);
     NotificationSender smsSender = new NotificationSender(smsStrategy);

     // Create and configure notification manager
     NotificationManager notificationManager = new NotificationManager();
     notificationManager.subscribe("Strategy1", emailSender);
     notificationManager.subscribe("Strategy1", smsSender);

     // Read command line arguments
     String channel = args[0];
     String subject = args[1];
     String message = args[2];

     // Send notifications based on channel
     if (channel.equalsIgnoreCase("email")) {
         notificationManager.sendNotificationToSubscriber("user1", subject, message);
     } else if (channel.equalsIgnoreCase("sms")) {
         notificationManager.sendNotificationToSubscriber("user2", subject, message);
     }
 }








}
