package com.nagarro.dp.StrategyDP;

import com.nagarro.dp.Notification;

public class NotificationSender {
	 private Notification strategy;

	    public NotificationSender(Notification strategy) {
	        this.strategy = strategy;
	    }

	    public void sendNotification(String subject, String message) {
	        strategy.send(subject, message);
	    }

}
