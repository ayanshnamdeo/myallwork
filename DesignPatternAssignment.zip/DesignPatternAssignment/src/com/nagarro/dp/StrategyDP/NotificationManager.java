package com.nagarro.dp.StrategyDP;

import java.util.HashMap;
import java.util.Map;

public class NotificationManager {
	private Map<String, NotificationSender> subscribers = new HashMap<>();

    public void subscribe(String userId, NotificationSender sender) {
        subscribers.put(userId, sender);
    }

    public void sendNotificationToSubscriber(String userId, String subject, String message) {
        NotificationSender sender = subscribers.get(userId);
        if (sender != null) {
            sender.sendNotification(subject, message);
        } else {
            System.out.println("User " + userId + " is not subscribed.");
        }
    }

}
