package com.nagarro.dp.factoryDP;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.nagarro.dp.Notification;

public class Main {
	public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//
//        System.out.print("Enter notification channel (Email/SMS): ");
//        String channel = scanner.nextLine();
//
//        NotificationFactory factory;
//
//        if ("Email".equalsIgnoreCase(channel)) {
//            factory = new EmailNotifyFactory();
//        } else if ("SMS".equalsIgnoreCase(channel)) {
//            factory = new SMSNotify();
//        } else {
//            System.out.println("Invalid channel");
//            return;
//        }
//
//        System.out.print("Enter subject: ");
//        String subject = scanner.nextLine();
//
//        System.out.print("Enter message body: ");
//        String message = scanner.nextLine();
//
//        Notification notification = factory.createNotification();
//        notification.send(subject, message);
//
//        scanner.close();
		
		if (args.length < 3) {
            System.out.println("Usage: java NotificationSystem <channel> <subject> <message>");
            return;
        }

        String channel = args[0].toLowerCase();
        String subject = args[1];
        String message = args[2];

        // Mocked user subscription data
        List<String> subscribedUsers = getSubscribedUsers();

        // Create the appropriate notification factory
        NotificationFactory factory;
        if (channel.equals("email")) {
            factory = new EmailNotifyFactory();
        } else if (channel.equals("sms")) {
            factory = new SMSNotify();
        } else {
            System.out.println("Unsupported channel: " + channel);
            return;
        }

        Notification notification = factory.createNotification();

        // Send notifications to subscribed users
        for (String user : subscribedUsers) {
            notification.send(subject, message);
            System.out.println("Sent to: " + user);
        }
    }

    // Mocked method to get subscribed users
    private static List<String> getSubscribedUsers() {
        List<String> subscribedUsers = new ArrayList<>();
        subscribedUsers.add("factory1@example.com");
        subscribedUsers.add("factory2@example.com");
        subscribedUsers.add("1234567890"); // Mocked phone number
        return subscribedUsers;
    }
		
		
    }


