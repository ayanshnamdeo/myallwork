package com.nagarro.dp.factoryDP;

import com.nagarro.dp.Notification;

public interface NotificationFactory {
	Notification createNotification();
}
