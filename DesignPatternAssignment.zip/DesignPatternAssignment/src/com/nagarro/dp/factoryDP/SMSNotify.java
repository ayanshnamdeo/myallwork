package com.nagarro.dp.factoryDP;

import com.nagarro.dp.Notification;
import com.nagarro.dp.SMS;

public class SMSNotify implements NotificationFactory {

	@Override
	public Notification createNotification() {
		// TODO Auto-generated method stub
		return new SMS();
	}

}
