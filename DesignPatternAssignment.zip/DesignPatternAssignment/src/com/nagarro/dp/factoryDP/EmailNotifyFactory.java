package com.nagarro.dp.factoryDP;

import com.nagarro.dp.Email;
import com.nagarro.dp.Notification;

public class EmailNotifyFactory implements NotificationFactory{

	@Override
	public Notification createNotification() {
		// TODO Auto-generated method stub
		return new Email();
	}


	}


