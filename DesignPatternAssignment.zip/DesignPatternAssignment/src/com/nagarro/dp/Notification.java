package com.nagarro.dp;

public interface Notification {

	void send(String subject,String message);
}
