package com.nagarro.dp.ObserverDP;

import com.nagarro.dp.Email;
import com.nagarro.dp.Notification;
import com.nagarro.dp.SMS;

public class MainObserver {
	public static void main(String[] args) {
        // Create notification system
        NotificationSystem notificationSystem = new NotificationSystem();

        // Create and add subscribers
        Notification emailSubscriber = new Email();
        Notification smsSubscriber = new SMS();
        
        notificationSystem.addObserver(emailSubscriber);
        notificationSystem.addObserver(smsSubscriber);

        // Read command line arguments
        String channel = args[0];
        String subject = args[1];
        String message = args[2];

        // Send notifications based on channel
        notificationSystem.notifyObservers(subject, message);
    }

}
