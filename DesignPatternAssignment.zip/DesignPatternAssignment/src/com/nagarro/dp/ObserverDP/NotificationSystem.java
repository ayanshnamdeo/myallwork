package com.nagarro.dp.ObserverDP;

import java.util.ArrayList;
import java.util.List;

import com.nagarro.dp.Notification;

public class NotificationSystem implements Subject{
	 private List<Notification> observers = new ArrayList<>();

	    @Override
	    public void addObserver(Notification observer) {
	        observers.add(observer);
	    }

	    @Override
	    public void removeObserver(Notification observer) {
	        observers.remove(observer);
	    }

	    @Override
	    public void notifyObservers(String subject, String message) {
	        for (Notification observer : observers) {
	            observer.send(subject, message);
	        }
	    }
	    
	    private List<String> getSubscribedUsers() {
	        List<String> subscribedUsers = new ArrayList<>();
	        subscribedUsers.add("Observer1@example.com");
	        subscribedUsers.add("Observer2@example.com");
	        subscribedUsers.add("1234567890"); // Mocked phone number
	        return subscribedUsers;
	    }

}
