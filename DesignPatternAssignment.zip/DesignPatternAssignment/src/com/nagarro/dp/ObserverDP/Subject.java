package com.nagarro.dp.ObserverDP;

import com.nagarro.dp.Notification;

public interface Subject {
	 void addObserver(Notification observer);
	    void removeObserver(Notification observer);
	    void notifyObservers(String subject, String message);

}
