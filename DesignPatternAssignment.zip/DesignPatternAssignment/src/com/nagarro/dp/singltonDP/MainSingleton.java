package com.nagarro.dp.singltonDP;

import java.util.Scanner;

import com.nagarro.dp.Email;
import com.nagarro.dp.SMS;
import com.nagarro.dp.factoryDP.EmailNotifyFactory;
import com.nagarro.dp.factoryDP.SMSNotify;

public class MainSingleton {
	
	 public static void main(String[] args) {
//		   Scanner scanner = new Scanner(System.in);
//	        Email emailChannel = new Email();
//	        SMS smsChannel = new SMS();
//
//	        NotificationSystem notificationSystem = NotificationSystem.getInstance();

//	        // Set the desired channel
//	        notificationSystem.setChannel(emailChannel);
//	        
//	        String subject = "Important Notification";
//	        String message = "This is an important message.";
//
//	        notificationSystem.sendNotification(subject, message);
//	        
//	        // Change the channel
//	        notificationSystem.setChannel(smsChannel);
//	        notificationSystem.sendNotification(subject, message);
//	        
//	        
	        
	        if (args.length < 3) {
	            System.out.println("Usage: java Main <channel> <subject> <message>");
	            return;
	        }

	        String channel = args[0].toLowerCase();
	        String subject = args[1];
	        String message = args[2];

	        NotificationSystem notificationSystem  = NotificationSystem .getInstance();
	        notificationSystem.sendNotifications(channel, subject, message);
	    }
	}
	



