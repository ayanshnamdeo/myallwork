package com.nagarro.dp.singltonDP;

import java.util.ArrayList;
import java.util.List;

import com.nagarro.dp.Notification;
import com.nagarro.dp.factoryDP.EmailNotifyFactory;
import com.nagarro.dp.factoryDP.NotificationFactory;
import com.nagarro.dp.factoryDP.SMSNotify;

public class NotificationSystem {
	
//	private static NotificationSystem instance;
//    private Notification channel;
//    //
//    private List<String> subscribedUsers;
//
//    private NotificationSystem() {
//        // Private constructor to prevent external instantiation
//    	//
//    	subscribedUsers = getSubscribedUsers();
//    }
//
//    public static synchronized NotificationSystem getInstance() {
//        if (instance == null) {
//            instance = new NotificationSystem();
//        }
//        return instance;
//    }
//
//    public void setChannel(Notification channel) {
//        this.channel = channel;
//    }
//
//    public void sendNotification(String subject, String message) {
//        if (channel != null) {
//            channel.send(subject, message);
//        } else {
//            System.out.println("No notification channel set.");
//        }
//    }

	
	  private static NotificationSystem instance;

	    private List<String> subscribedUsers;

	    private NotificationSystem() {
	        subscribedUsers = getSubscribedUsers();
	    }

	    public static synchronized NotificationSystem getInstance() {
	        if (instance == null) {
	            instance = new NotificationSystem();
	        }
	        return instance;
	    }

	    public void sendNotifications(String channel, String subject, String message) {
	        NotificationFactory factory = null;

	        if (channel.equals("email")) {
	            factory = new EmailNotifyFactory();
	        } else if (channel.equals("sms")) {
	            factory = new SMSNotify();
	        } else {
	            System.out.println("Unsupported channel: " + channel);
	            return;
	        }

	        Notification notification = factory.createNotification();

	        // Send notifications to subscribed users
	        for (String user : subscribedUsers) {
	            notification.send(subject, message);
	            System.out.println("Sent to: " + user);
	        }
	    }

	    private List<String> getSubscribedUsers() {
	        List<String> subscribedUsers = new ArrayList<>();
	        subscribedUsers.add("Singleton1@example.com");
	        subscribedUsers.add("Singleton2@example.com");
	        subscribedUsers.add("1234567890"); // Mocked phone number
	        return subscribedUsers;
	    }
	
}
