package com.nagarro.bankingApp2Account;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingApp2AccountApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingApp2AccountApplication.class, args);
	}

}
