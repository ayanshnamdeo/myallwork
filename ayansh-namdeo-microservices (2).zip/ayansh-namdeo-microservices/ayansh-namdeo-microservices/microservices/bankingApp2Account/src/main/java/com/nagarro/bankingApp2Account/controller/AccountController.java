package com.nagarro.bankingApp2Account.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//import com.nagarro.bankingApp.entity.Customer;
import com.nagarro.bankingApp2Account.entity.Account;
import com.nagarro.bankingApp2Account.service.AccountService;
import com.nagarro.bankingApp2Account.valueObject.ResponseTemplateVO;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/accounts")
@Slf4j
public class AccountController {

	@Autowired
	private AccountService accountService;

	@PostMapping("/")
	public ResponseEntity<Account> AddAccount(@RequestBody Account account) {
		return accountService.saveAccount(account);
	}

	@PutMapping("/deposit/{id}")
	public String addMoney(@PathVariable(value = "id") long id, @RequestBody Account account) {
		return accountService.deposit(id, account);

	}

	@PutMapping("/withdraw/{id}")
	public String withdrawMoney(@PathVariable(value = "id") long id, @RequestBody Account account) {
		return accountService.withdraw(id, account);

	}
	
	@GetMapping("/{id}")
	public Account findAccountById(@PathVariable("id") Long accountId) {
		return accountService.findAccountByAccountId(accountId);
	}
	
	@DeleteMapping("/{id}")
	public String deleteByCustomerId(@PathVariable("id") Long customerId) {
//		log.info("Inside findCustomerById method of CustomerController ");
		return accountService.delete(customerId);
	}

@GetMapping("/getAll")
public List<Account> getAllAccount() {
//	log.info("Inside findCustomerById method of CustomerController ");
	return accountService.getAllAccount();
}
}