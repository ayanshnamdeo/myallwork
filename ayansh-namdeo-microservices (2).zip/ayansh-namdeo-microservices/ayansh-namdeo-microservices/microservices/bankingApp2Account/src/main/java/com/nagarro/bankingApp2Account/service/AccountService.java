package com.nagarro.bankingApp2Account.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.nagarro.bankingApp2Account.Repository.AccountRepository;
import com.nagarro.bankingApp2Account.entity.Account;
import com.nagarro.bankingApp2Account.valueObject.ResponseTemplateVO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AccountService {
	@Autowired
	private AccountRepository accountRepository;

	public ResponseEntity<Account> saveAccount(Account account) {
		// TODO Auto-generated method stub
		Account acc1 = new Account(account.getAccountId(), account.getBalance(), account.getCustomerId());
		if (!accountRepository.existsById(acc1.getAccountId())) {
			return new ResponseEntity<Account>(accountRepository.save(account), HttpStatus.CREATED);
		} else {
			System.out.println("account already exist");
			return new ResponseEntity<Account>(HttpStatus.ALREADY_REPORTED);
		}
	}

//	public ResponseTemplateVO getAccountwithCustomer(Long accountId) {
//		ResponseTemplateVO vo = new ResponseTemplateVO();
//		Account account = accountRepository.findById(accountId);  // 26:39 showing some error at these line
//	}

	public Account findAccountByAccountId(Long accountId) {
		return accountRepository.findAccountByAccountId(accountId);
	}
	
	public String delete(Long customerId) {
		accountRepository.deleteByCustomerId(customerId);
		return "Deleted successfully!";
		
	}

	public String deposit(long id, Account account) {

		Account acc = accountRepository.findById(id).get();

		long final_amount = acc.getBalance() + account.getBalance();
		acc.setBalance(final_amount);
		accountRepository.save(acc);
		System.out.print(final_amount);
		return "success";
	}

	public String withdraw(long id, Account account) {

		Account acc = accountRepository.findById(id).get();

		if (acc.getBalance() < account.getBalance()) {
			return "insufficiet fund";
		} else {
			long final_amount = acc.getBalance() - account.getBalance();
			acc.setBalance(final_amount);
			accountRepository.save(acc);
			System.out.print(final_amount);
			return "success";
		}
	}

	public List<Account> getAllAccount() {
		// TODO Auto-generated method stub
		return accountRepository.findAll();
	}

	
}
