package com.nagarro.bankingApp2Account.Repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nagarro.bankingApp2Account.entity.Account;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long>{
	

	public Account findAccountByAccountId(Long accountId);

	@Transactional
	public void deleteByCustomerId(Long customerId);
}
