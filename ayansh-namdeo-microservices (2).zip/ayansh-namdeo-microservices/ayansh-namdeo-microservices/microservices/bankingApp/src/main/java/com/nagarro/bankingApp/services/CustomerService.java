package com.nagarro.bankingApp.services;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.nagarro.bankingApp.entity.Customer;
import com.nagarro.bankingApp.repository.CustomerRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CustomerService {

	@Autowired
	private CustomerRepository customerRepository; // obj of repo
	
	@Autowired
	private RestTemplate restTemplate;
	
	private static final String delete_account="http://localhost:9002/accounts/15";

	public ResponseEntity<Customer> saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
//		log.info("inside saveCustomer of customerservice");
		String uid =genrateId();
		customer.setTrackingId(uid);
		
		Customer customer1=new Customer(
				customer.getCustomerId(),
				customer.getCustomerName(),
				customer.getCustomerAddress(),
				customer.getCustomerBalance(),
				customer.getTrackingId()
				);
		if(! customerRepository.existsById(customer1.getCustomerId())) {
//			return customerRepository.save(customer);
			 return new ResponseEntity<Customer>(customerRepository.save(customer), HttpStatus.CREATED);
			
		}
		else {
			System.out.println("customer already exist");
			return new ResponseEntity<Customer>(HttpStatus.ALREADY_REPORTED);
//			return new customer1(HttpStatus.NOT_FOUND);;
		}
//		return customerRepository.save(customer);
		
	}

	public Customer findCustomerById(Long customerId) {
//		log.info("inside saveCustomer of customerservice");
		return customerRepository.findByCustomerId(customerId);
	}
	public List<Customer> findallCustomer() {
		return customerRepository.findAll();
	}
	public String delete(Long customerId) {

		customerRepository.deleteById(customerId);
		return "Deleted successfully!";
		
	}
	public void update(Customer customer) {
		customerRepository.save(customer);
		
	}
//	public Customer update(Long customerId, Customer customers){
//		Customer existingcustomer = customerRepository.findByCustomerId(customerId);
//		existingcustomer.setCustomerName(customers.getCustomerName());
//		existingcustomer.setCustomerAddress(customers.getCustomerAddress());
//		existingcustomer.setCustomerBalance(customers.getCustomerBalance());
//		Customer c = customerRepository.save(existingcustomer);
//		
//		return c;
//		
//	}
	private String genrateId() {
		return UUID.randomUUID().toString();
	}

}
