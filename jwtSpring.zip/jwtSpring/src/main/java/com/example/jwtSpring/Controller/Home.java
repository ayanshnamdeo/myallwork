package com.example.jwtSpring.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Home {
	
	@RequestMapping("/welcome")
	public String welcome() {
		String text="this is welcome page";
		return text;
	}
	
	@RequestMapping("/getusers")
	public String getUser() {
		return "{\"name\":\"Ayansh\"}";
	}
	

}
