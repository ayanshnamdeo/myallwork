package com.example.jwtSpring.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.jwtSpring.Model.JwtRequest;
import com.example.jwtSpring.Model.JwtResponse;
import com.example.jwtSpring.Services.CustomUserDetailsService;
import com.example.jwtSpring.helper.JwtUtil;



@RestController
public class jwtController {
	
	@Autowired
	private AuthenticationManager authenticationManager ;
	
	@Autowired
	public CustomUserDetailsService customerUserDetailsService ;
	
	@Autowired
	private JwtUtil jwtUtil;
	
//	@GetMapping("/check")
//	public String getJwt() {
//		return ("Jwt Accessed");
//	}
	
	@RequestMapping(value="/token",method=RequestMethod.POST)
	public ResponseEntity<?> generateToken(@RequestBody JwtRequest jwtRequest) throws Exception{
		System.out.println(jwtRequest);
		try {
			this.authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(jwtRequest.getUsername(),jwtRequest.getPassword()));
			
		}
		catch(UsernameNotFoundException e) {
			e.printStackTrace();
			throw new Exception("USer Not found ");
		}
		catch(BadCredentialsException e) {
			e.printStackTrace();
			throw new Exception("bad Credentails ");
		}
		
		//fine area...
		
		UserDetails userDeails=this.customerUserDetailsService.loadUserByUsername(jwtRequest.getUsername());
		String token= this.jwtUtil.generateToken(userDeails);
		System.out.println("JWT"+token);
		
		//{"token":"value"}
		return  ResponseEntity.ok(new JwtResponse(token));
	}

}
