package com.nagarro.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.nagarro.entity.Author;
import com.nagarro.entity.Book;
import com.nagarro.entity.User;
import com.nagarro.service.impl.AuthorServiceImpl;
import com.nagarro.service.impl.BookServiceImpl;
import com.nagarro.service.impl.LoginServiceImpl;

@SpringBootTest
public class ServiceTests {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private AuthorServiceImpl authorService;

    @InjectMocks
    private BookServiceImpl bookService;

    @InjectMocks
    private LoginServiceImpl loginService;

    @Test
    public void testGetAuthors() {
        // Mocking the restTemplate response
        Author[] authorsArray = { new Author(), new Author() };
        when(restTemplate.getForEntity(anyString(), eq(Author[].class)))
            .thenReturn(new ResponseEntity<>(authorsArray, HttpStatus.OK));

        // Calling the service method
        List<Author> authors = authorService.getAuthors();

        // Verifying the results
        assertEquals(authorsArray.length, authors.size());
    }

    @Test
    public void testAddBook() {
        // Mocking the restTemplate response
        Book book = new Book(123, "Test Author", "Test Book");
        when(restTemplate.postForObject(anyString(), any(), eq(Book.class)))
            .thenReturn(book);

        // Calling the service method
        Book result = bookService.addBook(book);

        // Verifying the results
        assertEquals(book, result);
    }

    @Test
    public void testEditBook() {
        // Mocking the restTemplate response
        Book book = new Book(123, "Test Author", "Test Book");
        String url = "http://localhost:8082/";
        doNothing().when(restTemplate).put(url, book);

        // Calling the service method
        bookService.edit(book);

        // Verifying that restTemplate.put is called
        verify(restTemplate, times(1)).put(url, book);
    }

    @Test
    public void testDeleteBook() {
        // Mocking the restTemplate response
        int bookId = 123;
        String url = "http://localhost:8082/books/" + bookId;
        doNothing().when(restTemplate).delete(url);

        // Calling the service method
        bookService.delete(bookId);

        // Verifying that restTemplate.delete is called
        verify(restTemplate, times(1)).delete(url);
    }

    @Test
    public void testGetAllBooks() {
        // Mocking the restTemplate response
        Book[] booksArray = { new Book(), new Book() };
        when(restTemplate.getForEntity(anyString(), eq(Book[].class)))
            .thenReturn(new ResponseEntity<>(booksArray, HttpStatus.OK));

        // Calling the service method
        List<Book> books = bookService.getAllBook();

        // Verifying the results
        assertEquals(booksArray.length, books.size());
    }

    @Test
    public void testGetLogin() {
        // Mocking the restTemplate response
        String userName = "testUser";
        User user = new User();
        when(restTemplate.getForObject(anyString(), eq(User.class)))
            .thenReturn(user);

        // Calling the service method
        User result = loginService.getLogin(userName);

        // Verifying the results
        assertEquals(user, result);
    }
}
