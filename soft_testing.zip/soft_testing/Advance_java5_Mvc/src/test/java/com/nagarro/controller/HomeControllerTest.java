package com.nagarro.controller;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.web.servlet.MockMvc;
//
//@SpringBootTest
//@AutoConfigureMockMvc
//public class HomeControllerTest {
//
//    @Autowired
//    private MockMvc mockMvc;
//
//    @Test
//    public void testLoginPage() throws Exception {
//        mockMvc.perform(get("/login"))
//               .andExpect(status().isOk())
//               .andExpect(view().name("Login.jsp"));
//    }
//
//    @Test
//    public void testSuccessfulLogin() throws Exception {
//        mockMvc.perform(post("/login")
//               .param("userName", "validUserName")
//               .param("password", "validPassword"))
//               .andExpect(status().isOk())
//               .andExpect(view().name("welcome.jsp"))
//               .andExpect(model().attributeExists("tableDetails"));
//    }
//
//    @Test
//    public void testFailedLogin() throws Exception {
//        mockMvc.perform(post("/login")
//               .param("userName", "invalidUsername")
//               .param("password", "invalidPassword"))
//               .andExpect(status().isOk())
//               .andExpect(view().name("Login.jsp"));
//    }
//
//    @Test
//    public void testAddForm() throws Exception {
//        mockMvc.perform(get("/add"))
//               .andExpect(status().isOk())
//               .andExpect(view().name("add.jsp"))
//               .andExpect(model().attributeExists("authors"));
//    }
//
////    @Test
////    public void testAddBook() throws Exception {
////        mockMvc.perform(post("/addBook")
////               .param("bookCode", "123")
////               .param("bookName", "Test Book")
////               .param("author", "Test Author")
////               .param("date", "2022-01-01"))
////               .andExpect(status().isOk())
////               .andExpect(view().name("welcome.jsp"))
////               .andExpect(model().attributeExists("tableDetails"));
////    }
//    
//    @Test
//    public void testAddBook() throws Exception {
//        mockMvc.perform(post("/addBook")
//               .param("bookCode", "123")
//               .param("bookName", "Test Book")
//               .param("author", "Test Author")
//               .param("date", "2022-01-01"))
//               .andExpect(status().isOk())
//               .andExpect(view().name("welcome.jsp"))
//               .andExpect(model().attributeExists("tableDetails")); // Make sure it matches the attribute name in your controller
//    }
//
//
//    
//}


import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.result.StatusResultMatchers;
import org.springframework.test.web.servlet.result.ViewResultMatchers;
import org.springframework.web.servlet.ModelAndView;

import com.nagarro.entity.Author;
import com.nagarro.entity.Book;
import com.nagarro.entity.User;
import com.nagarro.service.impl.AuthorServiceImpl;
import com.nagarro.service.impl.BookServiceImpl;
import com.nagarro.service.impl.LoginServiceImpl;
import com.nagarro.services.AuthorService;
import com.nagarro.services.BookService;
import com.nagarro.services.LoginService;

@WebMvcTest(HomeController.class)
public class HomeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LoginServiceImpl loginService;

    @MockBean
    private BookServiceImpl bookService;

    @MockBean
    private AuthorServiceImpl authorService;

    @Test
    public void testLoginController_ValidUser() throws Exception {
        User mockUser = new User();
        mockUser.setUserName("testUser");
        mockUser.setPassword("testPassword");

        when(loginService.getLogin(anyString())).thenReturn(mockUser);

        mockMvc.perform(MockMvcRequestBuilders.post("/login")
                .param("userName", "testUser")
                .param("password", "testPassword"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("welcome.jsp"));
    }

    @Test
    public void testLoginController_InvalidUser() throws Exception {
        when(loginService.getLogin(anyString())).thenReturn(null);

        mockMvc.perform(MockMvcRequestBuilders.post("/login")
                .param("userName", "invalidUser")
                .param("password", "invalidPassword"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("Login.jsp"));
    }

    @Test
    public void testAddFormController() throws Exception {
        List<Author> mockAuthors = new ArrayList<>();
        when(authorService.getAuthors()).thenReturn(mockAuthors);

        mockMvc.perform(MockMvcRequestBuilders.get("/add"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("add.jsp"));
    }
    
    @Test
    public void testAddBookController() throws Exception {
        List<Book> mockBooks = new ArrayList<>();
        when(bookService.getAllBook()).thenReturn(mockBooks);

        mockMvc.perform(MockMvcRequestBuilders.post("/addBook")
                .param("bookCode", "1")
                .param("bookName", "Test Book")
                .param("author", "Test Author")
                .param("date", "2022-01-01"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("welcome.jsp"));
        System.out.println("checkk-"+mockBooks);

        verify(bookService, times(1)).addBook(any(Book.class));
        verify(bookService, times(1)).getAllBook();
    }

    @Test
    public void testEditController() throws Exception {
        List<Author> mockAuthors = new ArrayList<>();
        when(authorService.getAuthors()).thenReturn(mockAuthors);

        mockMvc.perform(MockMvcRequestBuilders.get("/edit")
                .param("id", "1"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("edit.jsp"));

        verify(authorService, times(1)).getAuthors();
    }
    
  
	
    @Test
    public void testDeleteController() throws Exception {
        List<Book> mockBooks = new ArrayList<>();
        when(bookService.getAllBook()).thenReturn(mockBooks);

        mockMvc.perform(MockMvcRequestBuilders.get("/delete")
                .param("id", "1"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.view().name("welcome.jsp"));

        verify(bookService, times(1)).delete(1);
        verify(bookService, times(1)).getAllBook();
    }


   
}

