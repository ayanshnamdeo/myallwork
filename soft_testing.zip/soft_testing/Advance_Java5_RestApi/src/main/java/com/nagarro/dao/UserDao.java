package com.nagarro.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nagarro.entity.User;

public interface UserDao extends JpaRepository<User, Integer> {
	@Query("from User where userName=?1")
	public User findbyUserName(String userName);
}
