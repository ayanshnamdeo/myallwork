package com.nagarro.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nagarro.entity.Book;
import com.nagarro.services.BookService;

@RestController
public class HomeController {
	@Autowired
	private BookService books;
	
	@GetMapping("/books")
	public List<Book> getBooks(){
		
		
		return this.books.getBooks();
		
	}
	@GetMapping("/books/{bookCode}")
	public Book getBook(@PathVariable int id) {
		return this.books.getBook(id);
		
	}
	
	@PostMapping(path="/books",consumes = "application/json")
	public Book addBook(@RequestBody Book book) {
		
		return this.books.addBook(book);
	}
	
	@PutMapping("/books")
	public Book updateBook(@RequestBody Book book) {
		return this.books.updateBook(book);
	}
	@DeleteMapping("/books/{bookCode}")
	public ResponseEntity<HttpStatus> deleteBook(@PathVariable int bookCode){
		try {
			this.books.deleteBook(bookCode);
			return new ResponseEntity<HttpStatus>(HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
