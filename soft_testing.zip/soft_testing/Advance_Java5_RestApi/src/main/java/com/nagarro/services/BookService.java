package com.nagarro.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nagarro.entity.Book;

@Service
public interface BookService {
	public List<Book> getBooks();

	public Book getBook(int id);

	public Book addBook(Book book);

	public void deleteBook(int bookCode);

	public Book updateBook(Book book);
}
