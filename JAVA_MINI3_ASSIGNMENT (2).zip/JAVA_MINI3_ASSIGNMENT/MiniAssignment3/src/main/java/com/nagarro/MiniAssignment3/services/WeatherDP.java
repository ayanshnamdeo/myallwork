package com.nagarro.MiniAssignment3.services;

import java.util.concurrent.ExecutionException;

import org.springframework.stereotype.Service;

import com.nagarro.MiniAssignment3.entity.WeatherReport;

@Service
public interface WeatherDP {

 WeatherReport fetchReport(String city,String zip) throws InterruptedException, ExecutionException;
}
