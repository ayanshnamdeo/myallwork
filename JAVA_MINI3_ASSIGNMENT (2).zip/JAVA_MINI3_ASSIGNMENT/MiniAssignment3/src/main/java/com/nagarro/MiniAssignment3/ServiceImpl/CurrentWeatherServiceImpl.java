package com.nagarro.MiniAssignment3.ServiceImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.nagarro.MiniAssignment3.Exception.NoWeatherFoundException;
import com.nagarro.MiniAssignment3.SubEntities.GeoPosition;
import com.nagarro.MiniAssignment3.SubEntities.Key;
import com.nagarro.MiniAssignment3.entity.AccuWeather;
import com.nagarro.MiniAssignment3.entity.CurrentWeatherCondition;
import com.nagarro.MiniAssignment3.services.CurrentWeatherService;

@Component
public class CurrentWeatherServiceImpl implements CurrentWeatherService {

	private final WebClient webClient;

	public CurrentWeatherServiceImpl(WebClient webClient) {
		this.webClient = webClient;
	}

	@Value("${currentWeatherAPIKEY}")
	String apiKey;

	@Override
	public CurrentWeatherCondition fetchReport(String city) {
		String url = String.format("https://dataservice.accuweather.com/locations/v1/search?q=%s&apikey=%s", city,
				apiKey);
		List<Key> key = fetchKeyByUrl(url);
		String weatherKey = "";
		if (!key.isEmpty()) {
			weatherKey = key.get(0).getKey();
		} else {
			throw new NoWeatherFoundException("No such key find with this name ");
		}

		System.out.println(weatherKey);

		String weatherUrl = String.format("https://dataservice.accuweather.com/currentconditions/v1/%s?apikey=%s",
				weatherKey, apiKey);
		List<CurrentWeatherCondition> currentWeather = fetchCurrentWeatherByUrl(weatherUrl);
		if (currentWeather != null && !currentWeather.isEmpty() && currentWeather.size() != 0) {
			System.out.println("curr" + currentWeather.get(0));
			return currentWeather.get(0);
		}

		else {
			throw new NoWeatherFoundException("No weather find with this name " + city);
		}
	}

	public List<Key> fetchKeyByUrl(String url) {
//		return webClient.get().uri(url).retrieve().bodyToMono(new ParameterizedTypeReference<List<Key>>() {}).block();
		return webClient.get().uri(url).retrieve().bodyToMono(new ParameterizedTypeReference<List<Key>>() {}).block();
	}

	public List<CurrentWeatherCondition> fetchCurrentWeatherByUrl(String weatherUrl) {
		return webClient.get().uri(weatherUrl).retrieve()
				.bodyToMono(new ParameterizedTypeReference<List<CurrentWeatherCondition>>() {
				}).block();
	}
	
	
	

//	private final WebClient webClient;
//	private final ConcurrentHashMap<String,String> cc;
//	private final Map<String,CurrentWeatherCondition> map;
//	
//	
//	
//	public CurrentWeatherServiceImpl(WebClient webClient) {
//		this.webClient=webClient;
//		this.cc=new ConcurrentHashMap<>();
//		this.map=new HashMap<>();
//		}
//	@Value("${currentWeatherAPIKEY}")
//	String apiKey;

//	@Override
//	public CurrentWeatherCondition fetchReport(String city) {
//		
//		String stringKey=cc.get(city);
//		if(stringKey==null) {
//			String url=String.format("https://dataservice.accuweather.com/locations/v1/search?q=%s&apikey=%s",city,apiKey);
//			List<Key> key=webClient.get().uri(url).retrieve().bodyToMono(new ParameterizedTypeReference<List<Key>>(){}).block();
//			stringKey=key.get(0).getKey();
//			cc.put(city,stringKey);
//		}
//		String weatherUrl=String.format("https://dataservice.accuweather.com/currentconditions/v1/%s?apikey=%s", stringKey,apiKey);
//		List<CurrentWeatherCondition> currentWeather= webClient.get().uri(weatherUrl).retrieve().bodyToMono(new ParameterizedTypeReference<List<CurrentWeatherCondition>>(){}).block();
//		String id=currentWeather.get(0).getWeatherIcon();
//		if(map.containsKey(id)) {
//			 return map.get(id);
//		}
//		map.put(id,currentWeather.get(0) );
//		return currentWeather.get(0);
//		
//	}

	
	
//	 webClient.get().uri(url).retrieve().bodyToMono(Key[].class).flatMap(findKey->{
//			if(findKey!=null && findKey.length>0) {
//				Key key=findKey[0];
//				String weatherKey=key.getKey();
//				return weatherKey;
}
