package com.nagarro.MiniAssignment3.SubEntities;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Main {

	@JsonProperty("temp")
	private Long temp;
	
	@JsonProperty("feels_like")
	private Long feels_like;
	
	@JsonProperty("temp_min")
	private Long temp_min;
	
	@JsonProperty("temp_max")
	private Long temp_max;
	
	@JsonProperty("pressure")
	private Integer pressure;
	
	@JsonProperty("humidity")
	private Integer humidity;
	
	@JsonProperty("sea_level")
	private Integer sea_level;
	
	@JsonProperty("grnd_level")
	private Integer grnd_level;

	public Long getTemp() {
		return temp;
	}

	public void setTemp(Long temp) {
		this.temp = temp;
	}

	public Long getFeels_like() {
		return feels_like;
	}

	public void setFeels_like(Long feels_like) {
		this.feels_like = feels_like;
	}

	public Long getTemp_min() {
		return temp_min;
	}

	public void setTemp_min(Long temp_min) {
		this.temp_min = temp_min;
	}

	public Long getTemp_max() {
		return temp_max;
	}

	public void setTemp_max(Long temp_max) {
		this.temp_max = temp_max;
	}

	public Integer getPressure() {
		return pressure;
	}

	public void setPressure(Integer pressure) {
		this.pressure = pressure;
	}

	public Integer getHumidity() {
		return humidity;
	}

	public void setHumidity(Integer humidity) {
		this.humidity = humidity;
	}

	public Integer getSea_level() {
		return sea_level;
	}

	public void setSea_level(Integer sea_level) {
		this.sea_level = sea_level;
	}

	public Integer getGrnd_level() {
		return grnd_level;
	}

	public void setGrnd_level(Integer grnd_level) {
		this.grnd_level = grnd_level;
	}
	
	
}
