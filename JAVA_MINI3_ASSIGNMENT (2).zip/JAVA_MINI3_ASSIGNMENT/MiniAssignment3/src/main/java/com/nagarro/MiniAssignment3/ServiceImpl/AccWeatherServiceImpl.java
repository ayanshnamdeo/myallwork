package com.nagarro.MiniAssignment3.ServiceImpl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.nagarro.MiniAssignment3.SubEntities.GeoPosition;
import com.nagarro.MiniAssignment3.entity.AccuWeather;
import com.nagarro.MiniAssignment3.services.AccWeatherService;

@Component
public class AccWeatherServiceImpl implements AccWeatherService {

	WebClient webClient;
	public AccWeatherServiceImpl(WebClient webClient) {
		this.webClient=webClient;
	}
	
	@Value("${accuWeatherAPIEY}")
	String apiKey;
	
	@Override
	public AccuWeather fetchReport(String zip) {
		
		String url=String.format("https://api.openweathermap.org/geo/1.0/zip?zip=%s&appid=%s",zip,apiKey);
		System.out.println(zip+""+apiKey);
		GeoPosition geo=fetchGeoPositionByUrl(url);
	
		url=String.format("https://api.openweathermap.org/data/2.5/weather?lat=%s&lon=%s&appid=%s",geo.getLat(),geo.getLon(),apiKey);
		AccuWeather accuWeather=fetchAccuWeatherByUrl(url);
		return accuWeather;
	}
	
	
	
	public GeoPosition fetchGeoPositionByUrl(String url) {
		return webClient.get().uri(url).retrieve().bodyToMono(GeoPosition.class).block();
	}
	
	public AccuWeather fetchAccuWeatherByUrl(String url) {
		System.out.println("accu"+webClient.get().uri(url).retrieve().bodyToMono(String.class).block());
		return webClient.get().uri(url).retrieve().bodyToMono(AccuWeather.class).block();
	}
	
	
	
	
	
	
	
	
}
