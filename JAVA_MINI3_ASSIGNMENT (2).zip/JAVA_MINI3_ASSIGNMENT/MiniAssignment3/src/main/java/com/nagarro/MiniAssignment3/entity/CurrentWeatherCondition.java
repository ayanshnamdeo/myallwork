package com.nagarro.MiniAssignment3.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.nagarro.MiniAssignment3.SubEntities.TemperatureType;

public class CurrentWeatherCondition {

	@JsonProperty("LocalObservervationDateTime")
	private String LocalObservationDateTime;
	
	@JsonProperty("WeatherText")
	private String WeatherText;
	
	@JsonProperty("WeatherIcon")
	private String WeatherIcon;
	
	@JsonProperty("HasPrecipitation")
	private boolean HasPrecipitation;
	
	@JsonProperty("PrecipitationType")
	private String PrecipitationType;
	
	@JsonProperty("IsDayTime")
	private boolean IsDayTime;
	
	@JsonProperty("Temperature")
	private TemperatureType Temperature;
	
	@JsonProperty("MobileLink")
	private String MobileLink;
	
	@JsonProperty("Link")
	private String Link;

	
	

	public String getLocalObservationDateTime() {
		return LocalObservationDateTime;
	}




	public void setLocalObservationDateTime(String localObservationDateTime) {
		this.LocalObservationDateTime = localObservationDateTime;
	}




	public String getWeatherText() {
		return WeatherText;
	}




	public void setWeatherText(String weatherText) {
		this.WeatherText = weatherText;
	}




	public String getWeatherIcon() {
		return WeatherIcon;
	}




	public void setWeatherIcon(String weatherIcon) {
		this.WeatherIcon = weatherIcon;
	}




	public boolean isHasPrecipitation() {
		return HasPrecipitation;
	}




	public void setHasPrecipitation(boolean hasPrecipitation) {
		this.HasPrecipitation = hasPrecipitation;
	}




	public String getPrecipitationType() {
		return PrecipitationType;
	}




	public void setPrecipitationType(String precipitationType) {
		this.PrecipitationType = precipitationType;
	}




	public boolean isIsDayTime() {
		return IsDayTime;
	}




	public void setIsDayTime(boolean isDayTime) {
		this.IsDayTime = isDayTime;
	}




	public TemperatureType getTemperature() {
		return Temperature;
	}




	public void setTemperature(TemperatureType temperature) {
		this.Temperature = temperature;
	}




	public String getMobileLink() {
		return MobileLink;
	}




	public void setMobileLink(String mobileLink) {
		this.MobileLink = mobileLink;
	}




	public String getLink() {
		return Link;
	}




	public void setLink(String link) {
		this.Link = link;
	}




	@Override
	public String toString() {
		return "To String CurrentWeatherCondition [LocalObservationDateTime=" + LocalObservationDateTime + ", WeatherText="
				+ WeatherText + ", WeatherIcon=" + WeatherIcon + ", HasPrecipitation=" + HasPrecipitation
				+ ", PrecipitationType=" + PrecipitationType + ", IsDayTime=" + IsDayTime + ", Temperature="
				+ Temperature + ", MobileLink=" + MobileLink + ", Link=" + Link + "]";
	}

	
	
	
	
	
}
