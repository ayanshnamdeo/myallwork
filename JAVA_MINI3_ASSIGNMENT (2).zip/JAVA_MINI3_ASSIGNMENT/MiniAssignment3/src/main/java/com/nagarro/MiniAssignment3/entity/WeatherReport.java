package com.nagarro.MiniAssignment3.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.nagarro.MiniAssignment3.SubEntities.Main;
import com.nagarro.MiniAssignment3.SubEntities.Sys;
import com.nagarro.MiniAssignment3.SubEntities.TemperatureType;
import com.nagarro.MiniAssignment3.SubEntities.Wind;

public class WeatherReport {

	@JsonProperty("WeatherText")
	private String WeatherText;
	
	@JsonProperty("HasPrecipitation")
	private boolean HasPrecipitation;
	
	@JsonProperty("PrecipitationType")
	private String PrecipitationType;
	
	@JsonProperty("IsDayTime")
	private boolean IsDayTime;
	
	@JsonProperty("Temperature")
	private TemperatureType Temperature;
	//
	@JsonProperty("main")
	private Main main;
	
	@JsonProperty("visibility")
	private Long visibility;
	
	@JsonProperty("wind")
	private Wind wind;
	
	@JsonProperty("sys")
	private Sys sys;

	public String getWeatherText() {
		return WeatherText;
	}

	public void setWeatherText(String weatherText) {
		WeatherText = weatherText;
	}

	public boolean isHasPrecipitation() {
		return HasPrecipitation;
	}

	public void setHasPrecipitation(boolean hasPrecipitation) {
		HasPrecipitation = hasPrecipitation;
	}

	public String getPrecipitationType() {
		return PrecipitationType;
	}

	public void setPrecipitationType(String precipitationType) {
		PrecipitationType = precipitationType;
	}

	public boolean isIsDayTime() {
		return IsDayTime;
	}

	public void setIsDayTime(boolean isDayTime) {
		IsDayTime = isDayTime;
	}

	public TemperatureType getTemperature() {
		return Temperature;
	}

	public void setTemperature(TemperatureType temperature) {
		Temperature = temperature;
	}

	public Main getMain() {
		return main;
	}

	public void setMain(Main main) {
		this.main = main;
	}

	public Long getVisibility() {
		return visibility;
	}

	public void setVisibility(Long visibility) {
		this.visibility = visibility;
	}

	public Wind getWind() {
		return wind;
	}

	public void setWind(Wind wind) {
		this.wind = wind;
	}

	public Sys getSys() {
		return sys;
	}

	public void setSys(Sys sys) {
		this.sys = sys;
	}
	
	
}
