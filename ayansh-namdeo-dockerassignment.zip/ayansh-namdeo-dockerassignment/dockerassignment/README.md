

1.	 Share GitHub public repository URL for your code base.

https://github.com/ayanshNamdeo12/demo


2.	Share the Image path from Docker Hub Repo.

https://hub.docker.com/r/ayansh10999/demodockernew







