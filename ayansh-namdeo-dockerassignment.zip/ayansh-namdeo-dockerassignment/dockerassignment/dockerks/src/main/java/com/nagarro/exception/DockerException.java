package com.nagarro.exception;

public class DockerException  extends Exception {
	
	private static final long serialVersionUID = 1L;
	
		public DockerException(String message) {
			super(message);
		}

}
