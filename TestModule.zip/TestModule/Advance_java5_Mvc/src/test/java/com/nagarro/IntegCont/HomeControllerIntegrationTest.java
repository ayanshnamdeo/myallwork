package com.nagarro.IntegCont;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class HomeControllerIntegrationTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @LocalServerPort
    private int port;

    @Test
    public void testLoginController_ValidUser() {
        ResponseEntity<String> response = restTemplate.postForEntity(
                "http://localhost:" + port + "/login?userName=ayansh&password=ayansh%40123", null, String.class);

        assert response.getStatusCode() == HttpStatus.OK;
        assert response.getBody().contains("welcome.jsp");
//        response.getBody().
    }

    @Test
    public void testLoginController_InvalidUser() {
        ResponseEntity<String> response = restTemplate.postForEntity(
                "http://localhost:" + port + "/login?userName=invalidUser&password=invalidPassword", null, String.class);

//        assert response.getStatusCode() == HttpStatus.OK;
//        assert response.getBody().contains("Login.jsp");
        assertEquals(response.getStatusCode(), HttpStatus.OK);
        assertEquals(response.getBody().contains("Login"), true);
        System.err.println(" nb"+response.getBody());
    }

    @Test
    public void testAddFormController() {
        ResponseEntity<String> response = restTemplate.getForEntity(
                "http://localhost:" + port + "/add", String.class);

        assert response.getStatusCode() == HttpStatus.OK;
        assert response.getBody().contains("add.jsp");
    }

    @Test
    public void testAddBookController() {
        ResponseEntity<String> response = restTemplate.postForEntity(
                "http://localhost:" + port + "/addBook?bookCode=33&bookName=MY+Life+in+indore&author=Abhis&date=18%2FJanuary%2F24",
                null, String.class);

        assert response.getStatusCode() == HttpStatus.OK;
        assert response.getBody().contains("welcome.jsp");
    }

    @Test
    public void testEditController() {
        ResponseEntity<String> response = restTemplate.getForEntity(
                "http://localhost:" + port + "/edit?edit-2=edit", String.class);

//        assert response.getStatusCode() == HttpStatus.OK;
        assertEquals(response.getStatusCode(), HttpStatus.OK);
        assertEquals(response.getBody().contains("edit"), false);
        System.err.println(" nb"+response.getBody());
//        assert response.getBody().contains("edit.jsp");
    }

    @Test
    public void testDeleteController() {
        ResponseEntity<String> response = restTemplate.getForEntity(
                "http://localhost:" + port + "/delete?delete-123=delete", String.class);
//
//        assert response.getStatusCode() == HttpStatus.OK;
//        assert response.getBody().contains("welcome.jsp");
        assertEquals(response.getStatusCode(), HttpStatus.OK);
        assertEquals(response.getBody().contains("welcome"), true);
        System.err.println(" nb"+response.getBody());
    }
}
