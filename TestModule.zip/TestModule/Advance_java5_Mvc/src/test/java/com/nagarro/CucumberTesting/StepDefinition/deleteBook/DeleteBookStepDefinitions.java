package com.nagarro.CucumberTesting.StepDefinition.deleteBook;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.assertEquals;

public class DeleteBookStepDefinitions {

    @Autowired
    private TestRestTemplate restTemplate;

    private ResponseEntity<String> response;

    @Given("the user is on the welcome page")
    public void userIsOnWelcomePage() {
      
    }

    @When("the user selects a book to delete")
    public void userSelectsBookToDelete() {
        String url = "/deleteBook?id=123";
        response = restTemplate.exchange(url, HttpMethod.DELETE, null, String.class);
    }

    @Then("the book should be deleted successfully")
    public void bookShouldBeDeletedSuccessfully() {
        assertEquals("Add your expected success response", response.getBody());
       
    }

    @When("the user selects a non-existent book to delete")
    public void userSelectsNonExistentBookToDelete() {
        String url = "/deleteBook?id=999";
        response = restTemplate.exchange(url, HttpMethod.DELETE, null, String.class);
    }

    @Then("an error should occur")
    public void errorShouldOccur() {
        assertEquals("Add your expected failure response", response.getBody());
      
    }
}

