package com.nagarro.CucumberTesting.TestRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/resources/features",glue={"com.nagarro.CucumberTesting.StepDefinition.addBook","com.nagarro.CucumberTesting.StepDefinition.deleteBook","com.nagarro.CucumberTesting.StepDefinition.editBook","com.nagarro.CucumberTesting.StepDefinition.login"})
public class TestRunner {

}
