package com.nagarro.CucumberTesting.StepDefinition.editBook;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.assertEquals;

public class EditBookStepDefinitions {

    @Autowired
    private TestRestTemplate restTemplate;

    private ResponseEntity<String> response;

    @Given("the user is on the edit book page")
    public void userIsOnEditBookPage() {
      
    }

    @When("the user modifies book details")
    public void userModifiesBookDetails() {
        String url = "/editBook";
        HttpEntity<String> requestEntity = new HttpEntity<>("bookCode=123&bookName=UpdatedBook&author=UpdatedAuthor&date=2022-01-18");
        response = restTemplate.exchange(url, HttpMethod.PUT, requestEntity, String.class);
    }

    @Then("the book should be edited successfully")
    public void bookShouldBeEditedSuccessfully() {
        assertEquals("Add your expected success response", response.getBody());

    }

    @When("the user enters invalid book details for editing")
    public void userEntersInvalidBookDetailsForEditing() {
        String url = "/editBook";
        HttpEntity<String> requestEntity = new HttpEntity<>("bookCode=456&bookName=&author=UpdatedAuthor&date=2022-01-18");
        response = restTemplate.exchange(url, HttpMethod.PUT, requestEntity, String.class);
    }

    @Then("the book should not be edited")
    public void bookShouldNotBeEdited() {
        assertEquals("Add your expected failure response", response.getBody());
        
    }
}

