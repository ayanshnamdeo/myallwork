package com.nagarro.CucumberTesting.StepDefinition.login;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.assertEquals;

public class LoginStepDefinitions {

    @Autowired
    private TestRestTemplate restTemplate;

    private ResponseEntity<String> response;

    @Given("the user is on the login page")
    public void userIsOnLoginPage() {
      
    }

    @When("the user enters valid credentials")
    public void userEntersValidCredentials() {
        String url = "/login?userName=validUsername&password=validPassword";
        response = restTemplate.exchange(url, HttpMethod.GET, null, String.class);
    }

    @Then("the user should be redirected to the welcome page")
    public void userShouldBeRedirectedToWelcomePage() {
        assertEquals(HttpStatus.OK, response.getStatusCode());
     
    }

    @When("the user enters invalid credentials")
    public void userEntersInvalidCredentials() {
        String url = "/login?userName=invalidUsername&password=invalidPassword";
        response = restTemplate.exchange(url, HttpMethod.GET, null, String.class);
    }

    @Then("the user should stay on the login page")
    public void userShouldStayOnLoginPage() {
        assertEquals(HttpStatus.OK, response.getStatusCode());
       
    }
}

