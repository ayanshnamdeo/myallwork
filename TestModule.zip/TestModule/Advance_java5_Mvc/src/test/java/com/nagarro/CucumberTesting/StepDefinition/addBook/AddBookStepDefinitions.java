package com.nagarro.CucumberTesting.StepDefinition.addBook;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.assertEquals;

public class AddBookStepDefinitions {

    @Autowired
    private TestRestTemplate restTemplate;

    private ResponseEntity<String> response;

    @Given("the user is on the add book page")
    public void userIsOnAddBookPage() {
       
    }

    @When("the user enters valid book details")
    public void userEntersValidBookDetails() {
        String url = "/addBook";
        HttpEntity<String> requestEntity = new HttpEntity<>("bookCode=123&bookName=SampleBook&author=SampleAuthor&date=2022-01-18");
        response = restTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);
    }

    @Then("the book should be added successfully")
    public void bookShouldBeAddedSuccessfully() {
        assertEquals("Add your expected success response", response.getBody());
       
    }

    @When("the user enters invalid book details")
    public void userEntersInvalidBookDetails() {
        String url = "/addBook";
        HttpEntity<String> requestEntity = new HttpEntity<>("bookCode=456&bookName=&author=InvalidAuthor&date=2022-01-18");
        response = restTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);
    }

    @Then("the book should not be added")
    public void bookShouldNotBeAdded() {
        assertEquals("Add your expected failure response", response.getBody());
        
    }
}

