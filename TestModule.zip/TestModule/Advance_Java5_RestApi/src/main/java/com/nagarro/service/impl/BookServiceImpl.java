package com.nagarro.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.nagarro.dao.BookDao;
import com.nagarro.entity.Book;
import com.nagarro.services.BookService;
@Component
public class BookServiceImpl implements BookService {
	@Autowired
	private BookDao bookDao;
	
	public BookServiceImpl() {
	}
	@Override
	public List<Book> getBooks() {
		// TODO Auto-generated method stub
		return bookDao.findAll();
	}
	@Override
	public Optional<Book> getBook(int bookCode) {
		// TODO Auto-generated method stub
		return bookDao.findById(bookCode);
	}
	@Override
	public Book addBook(Book book) {
		// TODO Auto-generated method stub
		bookDao.save(book);
		return book;
	}
	@Override
	public void deleteBook(int bookCode) {
		Book entity=bookDao.getOne(bookCode);
		bookDao.delete(entity);
	}
	@Override
	public Book updateBook(Book book) {
		// TODO Auto-generated method stub
		bookDao.save(book);
		return book;
	}

}
