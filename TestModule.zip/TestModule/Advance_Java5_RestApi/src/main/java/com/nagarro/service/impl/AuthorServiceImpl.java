package com.nagarro.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.nagarro.dao.AuthorDao;
import com.nagarro.entity.Author;
import com.nagarro.services.AuthorService;

@Component
public class AuthorServiceImpl implements AuthorService {
	@Autowired
	AuthorDao repo;
	@Override
	public List<Author> authors() {
		// TODO Auto-generated method stub
		return (List<Author>)repo.findAll();
	}
	@Override
	public Author addAuthor(Author author) {
		// TODO Auto-generated method stub
		repo.save(author);
		return author;
	}
	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		Author author=repo.getOne(id);
		repo.delete(author);
	}
	

}
