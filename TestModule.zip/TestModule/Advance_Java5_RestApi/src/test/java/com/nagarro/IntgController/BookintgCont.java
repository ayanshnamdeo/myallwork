package com.nagarro.IntgController;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.web.client.RestTemplate;

import com.nagarro.dao.Testh2Repository;
import com.nagarro.dao.Testh2bookRepository;
import com.nagarro.entity.Author;
import com.nagarro.entity.Book;

@SpringBootTest(webEnvironment=SpringBootTest.WebEnvironment.RANDOM_PORT)
public class BookintgCont {
	
	@LocalServerPort
	private int port;
	
	@Autowired
	private Testh2bookRepository h2Repo;
	
	private String baseUrl="http://localhost";
	
	private static RestTemplate restTemplate;
	
	@BeforeAll
	public static void init() {
		restTemplate=new RestTemplate();
	}
	
	@BeforeEach
	public void setUp() {
		baseUrl=baseUrl.concat(":").concat(port+"").concat("/books");
	}
	
	@Test
	public void testAddBook() {
		Book book=new Book();
		book.setBookCode(10);
		book.setDate("16/January/2024");
		book.setName("Unknown History of life");
		book.setAuthor("Robinson");
		Book response=restTemplate.postForObject(baseUrl, book, Book.class);
		assertEquals("Unknown History of life", response.getName());
		System.err.println(response.getName());
		System.err.println(h2Repo.findAll().size());
		assertEquals(13, h2Repo.findAll().size());
	}
	
	@Test
	@Sql(statements="insert into book (author, date, name, book_code) values ('Robinson', '15/January/24', 'Mogli2', 122)",executionPhase =Sql.ExecutionPhase.BEFORE_TEST_METHOD)
	@Sql(statements = "delete from book where book_code=122",executionPhase =Sql.ExecutionPhase.AFTER_TEST_METHOD )
	public void testGetBook() {
		List<Book> books=restTemplate.getForObject(baseUrl, List.class);
		assertEquals(14, books.size());
		System.err.println(books.size());
		System.err.println(h2Repo.findAll().size());
		assertEquals(13, h2Repo.findAll().size());
	}
	
	
	//get by code
	
	@Test
	@Sql(statements="insert into book (author, date, name, book_code) values ('Robinson', '16/January/24', 'Tarzan', 28)",executionPhase =Sql.ExecutionPhase.BEFORE_TEST_METHOD)
	@Sql(statements = "delete from book where book_code=28",executionPhase =Sql.ExecutionPhase.AFTER_TEST_METHOD )
	public void testGetBookByCode() {
		 Book book=restTemplate.getForObject(baseUrl+"/{bookCode}",Book.class,28);
		assertAll(
				()->assertNotNull(book),
				()->assertEquals(28, book.getBookCode()),
				()->assertEquals("Tarzan", book.getName())
				);
	}
	
	//put book or update
	
	
	
	
	@Test
	@Sql(statements="insert into book (author, date, name, book_code) values ('AntMan', '16/January/24', 'Cristines', 13)",executionPhase =Sql.ExecutionPhase.BEFORE_TEST_METHOD)
	public void testDeleteAuthor() {
		int recordCount=h2Repo.findAll().size();
		assertEquals(13,recordCount);
		System.err.println(recordCount);
		restTemplate.delete(baseUrl+"/{id}",13);
		System.err.println(recordCount);
		assertEquals(13,h2Repo.findAll().size());
	}

}
