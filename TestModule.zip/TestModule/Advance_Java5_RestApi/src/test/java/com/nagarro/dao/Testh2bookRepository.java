package com.nagarro.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nagarro.entity.Author;
import com.nagarro.entity.Book;


public interface Testh2bookRepository extends JpaRepository<Book, Integer> {

}