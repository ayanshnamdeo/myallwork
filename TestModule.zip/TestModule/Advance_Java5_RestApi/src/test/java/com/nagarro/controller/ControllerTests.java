package com.nagarro.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nagarro.entity.Author;
import com.nagarro.entity.Book;
import com.nagarro.entity.User;
import com.nagarro.services.AuthorService;
import com.nagarro.services.BookService;
import com.nagarro.services.UserService;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebMvcTest(controllers = {AuthorController.class, HomeController.class, UserController.class})
public class ControllerTests {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AuthorService authorService;
    
    @MockBean
    private AuthorController authorController;

    @MockBean
    private BookService bookService;

    @MockBean
    private UserService userService;

    @Autowired
    private ObjectMapper objectMapper;
    
    
    
//    @BeforeAll
//	public static void setupSpec() {
////		trader = new Trader(1001, "test", 10000);
////
////		equities.put(1, 10);
////		equities.put(2, 20);
////		equities.put(3, 30);
////		equities.put(4, 40);
////		equities.put(5, 50);
////		trader.setEquities(equities);
//		
//		Author author = new Author();
//        author.setId(1);
//        author.setName("John Doe");
//        Author author1 = new Author();
//        author1.setId(2);
//        author1.setName("Mike Doe");
//        Author author2 = new Author();
//        author2.setId(3);
//        author2.setName("Mike tyson");
//        
//        Book book = new Book();
//        book.setBookCode(1);
//        book.setAuthor("John Doe");
//        book.setName("Sample Book");
//        
//        
//        User user = new User();
//        user.setId(1);
//        user.setUserName("john_doe");
//        user.setPassword("password123");
//	}
    
    //get mapping

    @Test
    public void testAuthorController() throws Exception {
        // Mock data
        Author author = new Author();
        author.setId(1);
        author.setName("John Doe");
        Author author1 = new Author();
        author1.setId(2);
        author1.setName("Mike Doe");

        when(authorController.getAuthors()).thenReturn(List.of(author,author1));

        // Perform GET request and validate the response
        mockMvc.perform(get("/authors"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].name").value("John Doe"))
                .andExpect(jsonPath("$[1].id").value(2))
                .andExpect(jsonPath("$[1].name").value("Mike Doe"));

        // Verify that the service method was called
        verify(authorController, times(1)).getAuthors();
        System.out.println("cont"+authorController+""+author+author1);
        System.err.println(List.of(author,author1));
    }
    
    @Test
    public void testBookController() throws Exception {
        // Mock data
        Book book = new Book();
        book.setBookCode(1);
        book.setAuthor("John Doe");
        book.setName("Sample Book");

        when(bookService.getBooks()).thenReturn(List.of(book));

        // Perform GET request and validate the response
        mockMvc.perform(get("/books"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[0].bookCode").value(1))
                .andExpect(jsonPath("$[0].author").value("John Doe"))
                .andExpect(jsonPath("$[0].name").value("Sample Book"));

        // Verify that the service method was called
        verify(bookService, times(1)).getBooks();
        System.err.println(List.of(book));
    }

    @Test
    public void testUserController() throws Exception {
        // Mock data
        User user = new User();
        user.setId(1);
        user.setUserName("john_doe");
        user.setPassword("password123");

        when(userService.getUser("john_doe")).thenReturn(user);

        // Perform GET request and validate the response
        mockMvc.perform(get("/user/john_doe"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.userName").value("john_doe"))
                .andExpect(jsonPath("$.password").value("password123"));

        // Verify that the service method was called
        verify(userService, times(1)).getUser("john_doe");
    }
    
    //post mapping
    
    @Test
    public void testAddAuthor() {
        // Mocking data
        Author author3 = new Author();
        author3.setId(3);
        author3.setName("John Mike");
        when(authorService.addAuthor(author3)).thenReturn(author3);

        // Perform the test
        Author result = authorService.addAuthor(author3);

        // Verify the result
        assertEquals(author3, result);
        System.err.println(author3+""+result);
    }
    
    
    @Test
    public void testAddBook() {
        // Mocking data
    	 Book book3 = new Book();
         book3.setBookCode(3);
         book3.setAuthor("Kiplin");
         book3.setName("Jungle Book");
    	
    
        when(bookService.addBook(book3)).thenReturn(book3);

        // Perform the test
        Book result = bookService.addBook(book3);

        // Verify the result
        assertEquals(book3, result);
        System.err.println(book3+""+result);
    }
    
    @Test
    public void testAddUser() {
        // Mocking data
    	 User user3 = new User();
         user3.setId(3);
         user3.setUserName("yohan_jack");
         user3.setPassword("passwordjack123");
 
        when(userService.addUser(user3)).thenReturn(user3);

        // Perform the test
        User result = userService.addUser(user3);

        // Verify the result
        assertEquals(user3, result);
        System.err.println(user3+""+result);
    }

    
//    @Test
//    public void testDeleteAuthor() {
//        // Mocking data
//    	        try {
//            // ... (your existing test code)
//    	        	testAuthorController();
//    	     
//    	            int id = 2;
//
//
//            // Additional logging
//            System.out.println("Before performing the test action");
//
//            // Perform the test
//            ResponseEntity<HttpStatus> result = authorController.deleteAuthor(id);
////            assertEquals(HttpStatus.OK, result.getStatusCode());
//            
//            System.out.println("del"+result+authorService.authors());
//            verify(authorController, times(1)).deleteAuthor(id);
//            // Additional logging
//            System.out.println("After performing the test action");
//
//            // ... (rest of your existing test code)
//            // Verify the result
//         
//        } catch (Exception e) {
//            // Print the exception details for debugging
//            e.printStackTrace();
//        }
//       

        // Perform the test
//        ResponseEntity<HttpStatus> result = authorController.deleteAuthor(id);
//
//        // Verify the result
//        assertEquals(HttpStatus.OK, result.getStatusCode());
//        System.out.println("del"+result);
//        verify(authorController, times(1)).deleteAuthor(id);
//    }

}
