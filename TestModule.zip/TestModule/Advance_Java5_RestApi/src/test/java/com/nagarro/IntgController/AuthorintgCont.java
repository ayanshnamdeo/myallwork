package com.nagarro.IntgController;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.web.client.RestTemplate;

import com.nagarro.dao.Testh2Repository;
import com.nagarro.entity.Author;

@SpringBootTest(webEnvironment=SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AuthorintgCont {

	
	@LocalServerPort
	private int port;
	
	@Autowired
	private Testh2Repository h2Repo;
	
	private String baseUrl="http://localhost";
	
	private static RestTemplate restTemplate;
	
	@BeforeAll
	public static void init() {
		restTemplate=new RestTemplate();
	}
	
	@BeforeEach
	public void setUp() {
		baseUrl=baseUrl.concat(":").concat(port+"").concat("/authors");
	}
	
	@Test
	public void testAddAuthor() {
		Author author=new Author();
		 author.setId(111);
	     author.setName("Abhis");
		Author response=restTemplate.postForObject(baseUrl, author, Author.class);
		assertEquals("Abhis", response.getName());
		System.err.println(response.getName());
		System.err.println(h2Repo.findAll().size());
		assertEquals(12, h2Repo.findAll().size());
	}
	
	@Test
	@Sql(statements="insert into author (name, id) values ('birbala',118)",executionPhase =Sql.ExecutionPhase.BEFORE_TEST_METHOD)
	@Sql(statements = "delete from author where name='birbala'",executionPhase =Sql.ExecutionPhase.AFTER_TEST_METHOD )
	public void testGetAuthor() {
		List<Author> authorss=restTemplate.getForObject(baseUrl, List.class);
		assertEquals(14, authorss.size());
		System.err.println(authorss.size());
		System.err.println(h2Repo.findAll().size());
		assertEquals(14, h2Repo.findAll().size());
	}
	
	@Test
	@Sql(statements="insert into author (name, id) values ('Rajeshk',120)",executionPhase =Sql.ExecutionPhase.BEFORE_TEST_METHOD)
	public void testDeleteAuthor() {
		int recordCount=h2Repo.findAll().size();
		assertEquals(14,recordCount);
		System.err.println(recordCount);
		restTemplate.delete(baseUrl+"/{id}",120);
		System.err.println(recordCount);
		assertEquals(13,h2Repo.findAll().size());
	}
}
 