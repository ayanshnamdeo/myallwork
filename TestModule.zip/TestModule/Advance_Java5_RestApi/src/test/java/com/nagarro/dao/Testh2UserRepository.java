package com.nagarro.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nagarro.entity.User;

public interface Testh2UserRepository extends JpaRepository<User, Integer> {

}