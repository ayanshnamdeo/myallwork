package com.nagarro.IntgController;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.web.client.RestTemplate;

import com.nagarro.dao.Testh2Repository;
import com.nagarro.dao.Testh2UserRepository;
import com.nagarro.entity.Book;
import com.nagarro.entity.User;

@SpringBootTest(webEnvironment=SpringBootTest.WebEnvironment.RANDOM_PORT)
public class UserintgCont {
	@LocalServerPort
	private int port;
	
	@Autowired
	private Testh2UserRepository h2Repo;
	
	private String baseUrl="http://localhost";
	
	private static RestTemplate restTemplate;
	
	@BeforeAll
	public static void init() {
		restTemplate=new RestTemplate();
	}
	
	@BeforeEach
	public void setUp() {
		baseUrl=baseUrl.concat(":").concat(port+"").concat("/user");
	}
	
	@Test
	public void testAddUser() {
		User user=new User();
		user.setId(3);
		user.setUserName("arav");
		user.setPassword("arav@123");
		User response=restTemplate.postForObject(baseUrl, user, User.class);
		assertEquals("arav", response.getUserName());
		System.err.println(response.getUserName());
		System.err.println(h2Repo.findAll().get(1));
		assertEquals(5, h2Repo.findAll().size());
	}
	
	
	//get by name	
	@Test
	@Sql(statements="insert into user (password, user_name, id) values ('chintan', 'chinatan@123', 6)",executionPhase =Sql.ExecutionPhase.BEFORE_TEST_METHOD)
	@Sql(statements = "delete from user where id=6",executionPhase =Sql.ExecutionPhase.AFTER_TEST_METHOD )
	public void testGetUserByUsername() {
		 User user=restTemplate.getForObject(baseUrl+"/{username}",User.class,"ayansh");
		assertAll(
				()->assertNotNull(user),
				()->assertEquals(1, user.getId()),
				()->assertEquals("ayansh",user.getUserName())
				);
	}
	
	@Test
	@Sql(statements="insert into user (password, user_name, id) values ('chintan', 'chinatan@123', 6)",executionPhase =Sql.ExecutionPhase.BEFORE_TEST_METHOD)
	public void testDeleteUser() {
		int recordCount=h2Repo.findAll().size();
		assertEquals(6,recordCount);
		System.err.println(recordCount);
		restTemplate.delete(baseUrl+"/{id}",6);
		System.err.println(recordCount);
		assertEquals(5,h2Repo.findAll().size());
	}


}
