package com.nagarro.bankingApp2Account;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingApp2AccountApplicationTests {

	@Test
	void contextLoads() {
	}

}
