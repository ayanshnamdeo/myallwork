package com.nagarro.bankingApp2Account.valueObject;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Customer {
	
	private long customerId;
	private String customerName;
	private String customerAddress;
	private long customerBalance;

}
