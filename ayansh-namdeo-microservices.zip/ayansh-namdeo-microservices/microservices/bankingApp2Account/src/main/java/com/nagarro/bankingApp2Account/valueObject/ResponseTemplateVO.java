package com.nagarro.bankingApp2Account.valueObject;

import com.nagarro.bankingApp2Account.entity.Account;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseTemplateVO {
	
	private Customer customer;
	private Account account;

}
