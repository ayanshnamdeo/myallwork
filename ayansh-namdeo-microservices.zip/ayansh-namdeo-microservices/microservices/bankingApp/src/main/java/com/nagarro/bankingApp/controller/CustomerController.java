package com.nagarro.bankingApp.controller;

import java.io.InputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.nagarro.bankingApp.entity.Customer;
import com.nagarro.bankingApp.services.CustomerService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/customers")
@Slf4j // for loggers
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	// obj of service
	
	@Autowired
	private RestTemplate restTemplate;

	@PostMapping("/")
	public ResponseEntity<Customer> saveCustomer(@RequestBody Customer customer) {
//		log.info("Inside saveCustomer method of CustomerController ");
		return customerService.saveCustomer(customer);
	}



	@GetMapping("/{id}")
	public Customer findCustomerById(@PathVariable("id") Long customerId) {
//		log.info("Inside findCustomerById method of CustomerController ");
		return customerService.findCustomerById(customerId);
	}

	@GetMapping("/all")
	public List<Customer> findAll() {
//		log.info("Inside findCustomerById method of CustomerController ");
		return customerService.findallCustomer();
	}

	@DeleteMapping("/{id}")
	public void deleteById(@PathVariable("id") Long customerId) {
//		log.info("Inside findCustomerById method of CustomerController ");
		
		customerService.delete(customerId);
		restTemplate.delete("http://localhost:9002/accounts/"+customerId);
	}

	@PutMapping("/update")
	public Customer updateCustomer(@RequestBody Customer customer) {
		customerService.update(customer);
		return customer;

	}
//	@PutMapping("/{id}")
//	public Customer updateCustomers(@PathVariable("id") Long customerId , Customer customer)
//	{
//		return customerService.update(customerId, customer);
//	}

}
