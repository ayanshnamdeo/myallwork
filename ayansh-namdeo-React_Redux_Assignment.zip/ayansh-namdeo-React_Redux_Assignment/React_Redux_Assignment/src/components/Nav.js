import React from 'react';
import './Nav.css'
const Nav = () => {
    return (
        <div className='navbar'>
            <h1>BlogPost!</h1>
        </div>
    );
};

export default Nav;